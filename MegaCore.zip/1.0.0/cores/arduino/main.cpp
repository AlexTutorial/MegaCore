/*

*/

#include <Arduino.h>
#pragma message "Based on MegaCore v1.0.0"

int main(void)
{
	init();
	setup();
    
	for (;;) {
		loop();
		if (serialEventRun) serialEventRun();
	}
        
	return 0;
}

